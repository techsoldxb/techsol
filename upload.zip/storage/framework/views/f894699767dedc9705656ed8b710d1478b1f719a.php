<?php $__env->startSection('content'); ?>



   <!-- Main content -->
   <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
         
            <!-- /.card-header -->
        
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

          <div class="card">
            <div class="card-header">
              <h3 class="card-title">User List</h3>   
              
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                                   
                <th> User ID   </th>                       
            <th> User Name </th>
            <th> Email </th>
            <th> Company Name </th>
            <th> Type </th>
            
            <th> Created Date </th>
            <th> Verified Date</th>
            
         
                </tr>
                </thead>
                <tbody>
                
                <?php if(count($users)): ?>
            
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <tr>
            
                <td><?php echo e($c->id); ?></td>
                <td><?php echo e($c->name); ?></td>
                <td><?php echo e($c->email); ?></td>
                <td>
                  
                  <?php if($c->company =='1'): ?>
                    <?php echo e("Al Jarwani"); ?>

                  <?php elseif($c->company =='2'): ?>
                  <?php echo e("Mall Of Muscat"); ?>

                  <?php elseif($c->company =='3'): ?>
                  <?php echo e("Oman Aquarium"); ?>

                  <?php elseif($c->company =='4'): ?>
                  <?php echo e("Snow Village"); ?>

                  <?php endif; ?>
              
              </td>


              <td><?php echo e($c->user_type); ?></td>     
              <td><?php echo e(date('d-m-Y', strtotime($c->created_at))); ?></td>   
                
                <td><?php echo e(date('d-m-Y', strtotime($c->email_verified_at))); ?></td>   
            
            
            
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php else: ?>
            <tr><td colspan="11">No Record Found</td></tr>
            <?php endif; ?>

                </tbody>
                <tfoot>
                <tr>
                                 
                    <th> User ID   </th>                       
                    <th> User Name </th>
                    <th> Email </th>
                    <th> Company Name </th>
                    <th> Type </th>
                    
                    <th> Created Date </th>
                    <th> Verified Date</th>
                    
                </tr>
                </tfoot>
              </table>
              
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
   

<?php $__env->stopSection(); ?>

    
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\jarwani\resources\views/users.blade.php ENDPATH**/ ?>