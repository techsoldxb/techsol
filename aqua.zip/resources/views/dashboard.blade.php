@extends('layouts.adminlte')
@section('content')
<p>
This is the test home page
</p>
@endsection