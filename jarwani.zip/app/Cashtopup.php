<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cashtopup extends Model
{
    //
}
