<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Advance extends Model
{
    //
}
