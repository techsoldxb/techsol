<?php $__env->startSection('content'); ?>



   <!-- Main content -->
   <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
         
            <!-- /.card-header -->
        
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Paid Bills
              <a href="<?php echo e(route('admin.accounts.create')); ?>" class="btn btn-primary btn-sm">Add Bill</a></h3>   
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                                   
                <th> Tran No.   </th>                       
            <th> Tran Date </th>
            <th> Supplier Name </th>
            <th> Bill Date </th>
            <th> Bill No. </th>
            <th> Bill Amount </th>
            <th> Purpose </th>
            <th> Payment Date </th>
            <th> Action </th>
                </tr>
                </thead>
                <tbody>
                
                <?php if(count($accounts)): ?>
            
            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <tr>
            <td><a href="<?php echo e(url('storage/categories/'.$c->th_attach)); ?>" target="_blank"><?php echo e($c->th_tran_no); ?></a></td>            
            <td><?php echo e(date('d-m-Y', strtotime($c->created_at))); ?></td>            
            <td><?php echo e($c->th_supp_name); ?></td>
            <td><?php echo e(date('d-m-Y', strtotime($c->th_bill_dt))); ?></td>
            <td><?php echo e($c->th_bill_no); ?></td>
            <td class="text-right"><?php echo e(number_format($c->th_bill_amt,3)); ?></td>
            <td><?php echo e($c->th_purpose); ?></td>
            <td><?php echo e($c->th_pay_date); ?></td>

            
            
            
            
            <td>             
              <a href="<?php echo e(route('admin.accounts.print', $c)); ?>" >
              
              <i class="fa fa-print text-green" aria-hidden="true"></i>
              
              </a>
              
           

            
            <a href="<?php echo e(route('admin.accounts.edit',$c->th_tran_no)); ?>">
            
            
            </a>

            

            <a href="javascript:void(0)" onclick = "$(this).parent().find('form').submit()" >
            
            
            
            
            </a>
            <form action = "<?php echo e(route('admin.accounts.destroy', $c->id)); ?>" method = "POST">
            <?php echo method_field('DELETE'); ?>
            <input type="hidden" name="_token" value = "<?php echo e(csrf_token()); ?>">
            </form>
          </td>                
            
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php else: ?>
            <tr><td colspan="11">No Record Found</td></tr>
            <?php endif; ?>

                </tbody>
                <tfoot>
                <tr>
                                 
                <th> Tran No.   </th>                       
            <th> Tran Date </th>
            <th> Supplier Name </th>
            <th> Bill Date </th>
            <th> Bill No. </th>
            <th> Bill Amount </th>
            <th> Purpose </th>
            <th> Payment Date </th>
            <th> Action </th>
                </tr>
                </tfoot>
              </table>
              
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
   

<?php $__env->stopSection(); ?>

    
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\jarwani\resources\views/admin/paidbills/index.blade.php ENDPATH**/ ?>