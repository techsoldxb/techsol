<?php $__env->startSection('content'); ?>



   <!-- Main content -->
   <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
         
            <!-- /.card-header -->
        
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Cash Advance
              <a href="<?php echo e(route('admin.advances.create')); ?>" class="btn btn-primary btn-sm">Advance Request</a></h3>   
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>                                   
                  <th> ID  </th>                       
                  <th> Tran Date </th> 
                  <th> Request Date </th>                  
                  <th> Amount </th>             
                  <th> Reason</th>
                  <th> Action</th>
                  
                </tr>
                </thead>
                <tbody>
                
                <?php if(count($advances)): ?>
            
            <?php $__currentLoopData = $advances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <tr>
              <td><?php echo e($c->id); ?></td>            
            <td><?php echo e(date('d-m-Y', strtotime($c->created_at))); ?></td>                        
            <td><?php echo e(date('d-m-Y', strtotime($c->ca_adv_date))); ?></td>                   
         
            <td class="text-right"><?php echo e(number_format($c->ca_adv_amt,3)); ?></td>
         
            
            <td><?php echo e($c->ca_purpose); ?></td>
            
            
            <td>             
              
           

            
            

            <a href="javascript:void(0)" onclick = "$(this).parent().find('form').submit()" >
            
            
            <i class="fa fa-trash text-red"></i >
            
            </a>
            <form action = "<?php echo e(route('admin.advances.destroy', $c->id)); ?>" method = "POST">
            <?php echo method_field('DELETE'); ?>
            <input type="hidden" name="_token" value = "<?php echo e(csrf_token()); ?>">
            </form>
          </td>
                         
            
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php else: ?>
            <tr><td colspan="11">No Record Found</td></tr>
            <?php endif; ?>

                </tbody>
                <tfoot>
                <tr>
                                 
                  <th> ID  </th>    
                  <th> Tran Date </th>                    
                  <th> Request Date </th>                  
                  <th> Amount </th>             
                  <th> Reason</th>
                  <th> Action</th>
            
                </tr>
                </tfoot>
              </table>
              
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
   

<?php $__env->stopSection(); ?>

    
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\jarwani\resources\views/admin/advance/index.blade.php ENDPATH**/ ?>